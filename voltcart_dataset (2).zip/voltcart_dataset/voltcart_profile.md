# VoltCart - Company Profile (fictional)

**VoltCart** is an imaginary online electronics retailer. It sells its own-brand products and ships to customers nationally and internationally.

## Products
| Product | Price (USD) |
|---|---|
| VoltPhone A5 / X2 / Ultra | 349 / 699 / 1,099 |
| VoltBook Go 14 / Pro 15 | 549 / 1,299 |
| VoltTab 10 | 329 |
| VoltWatch S1 | 199 |
| VoltBuds Pro | 129 |
| VoltSound Mini | 59 |
| VoltCharge 65W Charger | 39 |
| VoltBank 20000 Power Bank | 49 |
| VoltCable USB-C 2m | 15 |
| VoltCart Gift Card $50 | 50 |

Only VoltPhone Ultra and VoltBook Pro 15 are above the $1,000 "high-value" threshold.

## Support departments
Returns, Billing, Shipping, Technical Support, Safety (plus Manager and Admin levels for escalations).

## Key business facts (used consistently everywhere)
- Refund window: 30 days (15 days for opened, non-faulty items, with a 15% restocking fee)
- Warranty: 12 months, repair or replace
- Damage must be reported within 7 days with photos; wrong/missing items within 14 days
- Compensation is **store credit only**. Agent up to $10, Manager up to $50, Admin above $50
- High-value order threshold: over $1,000
- Response times: High 1h / 24h, Medium 8h / 72h, Low 24h / 168h (first response / resolution)
