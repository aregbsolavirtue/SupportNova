const fs = require('fs');
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, WidthType, BorderStyle,
        ShadingType, HeadingLevel, AlignmentType, Header, Footer, PageNumber } = require('docx');

const P = JSON.parse(fs.readFileSync('policies.json', 'utf8'));
const border = { style: BorderStyle.SINGLE, size: 4, color: "BBBBBB" };
const borders = { top: border, bottom: border, left: border, right: border };
const F = "Arial";

function metaRow(k, v) {
  const cell = (t, w, bold, fill) => new TableCell({
    borders, width: { size: w, type: WidthType.DXA },
    shading: fill ? { fill, type: ShadingType.CLEAR, color: "auto" } : undefined,
    margins: { top: 60, bottom: 60, left: 100, right: 100 },
    children: [new Paragraph({ children: [new TextRun({ text: t, bold, font: F, size: 20 })] })],
  });
  return new TableRow({ children: [cell(k, 2400, true, "EEF2F7"), cell(v, 6960, false)] });
}

for (const p of P.filter(x => x.fmt === 'docx')) {
  const kids = [];
  kids.push(new Paragraph({ spacing: { after: 60 }, children: [new TextRun({ text: "VoltCart Internal Policy", font: F, size: 20, color: "666666" })] }));
  kids.push(new Paragraph({ heading: HeadingLevel.TITLE, spacing: { after: 160 },
    children: [new TextRun({ text: p.title, font: F, size: 40, bold: true })] }));
  if (p.banner) {
    kids.push(new Paragraph({ spacing: { after: 160 }, shading: { fill: "FDECEA", type: ShadingType.CLEAR, color: "auto" },
      children: [new TextRun({ text: p.banner, bold: true, color: "B00020", font: F, size: 22 })] }));
  }
  kids.push(new Table({
    width: { size: 9360, type: WidthType.DXA }, columnWidths: [2400, 6960],
    rows: [
      metaRow("Policy ID", p.id), metaRow("Version", p.version), metaRow("Status", p.status),
      metaRow("Effective date", p.effective), metaRow("Supersedes", p.supersedes || "None"),
      metaRow("Owner", p.owner + " team"), metaRow("Precedence level", String(p.precedence)),
    ],
  }));
  kids.push(new Paragraph({ heading: HeadingLevel.HEADING_1, spacing: { before: 240, after: 100 },
    children: [new TextRun({ text: "Purpose", font: F })] }));
  kids.push(new Paragraph({ spacing: { after: 120 }, children: [new TextRun({ text: p.purpose, font: F, size: 22 })] }));
  p.sections.forEach(([head, clauses], si) => {
    kids.push(new Paragraph({ heading: HeadingLevel.HEADING_1, spacing: { before: 240, after: 100 },
      children: [new TextRun({ text: `${si + 1}. ${head}`, font: F })] }));
    clauses.forEach((c, ci) => {
      kids.push(new Paragraph({ spacing: { after: 100 }, indent: { left: 540, hanging: 540 },
        children: [new TextRun({ text: `${si + 1}.${ci + 1}\t`, bold: true, font: F, size: 22 }),
                   new TextRun({ text: c, font: F, size: 22 })],
        tabStops: [{ type: "left", position: 540 }] }));
    });
  });
  const doc = new Document({
    styles: {
      default: { document: { run: { font: F, size: 22 } } },
      paragraphStyles: [
        { id: "Title", name: "Title", basedOn: "Normal", run: { size: 40, bold: true, font: F }, paragraph: { spacing: { after: 160 } } },
        { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
          run: { size: 26, bold: true, font: F, color: "1F3A5F" }, paragraph: { spacing: { before: 240, after: 100 }, outlineLevel: 0 } },
      ],
    },
    sections: [{
      properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
      headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT,
        children: [new TextRun({ text: `${p.id} | v${p.version} | ${p.status}`, font: F, size: 18, color: "888888" })] })] }) },
      footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER,
        children: [new TextRun({ text: "VoltCart (fictional company) - Page ", font: F, size: 18, color: "888888" }),
                   new TextRun({ children: [PageNumber.CURRENT], font: F, size: 18, color: "888888" })] })] }) },
      children: kids,
    }],
  });
  Packer.toBuffer(doc).then(buf => fs.writeFileSync(`out/policies/${p.file_name}`, buf));
}
