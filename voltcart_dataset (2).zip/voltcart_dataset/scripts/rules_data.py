"""VoltCart Rule Matrix source data (100 rules).
Each rule also carries two complaint templates (A = polite/detailed, B = short/casual)
used to generate the complaints dataset, so complaints and rules can never disagree."""

DEPT = {
    "Damaged Product": "Returns",
    "Refund Request": "Billing",
    "Billing Error": "Billing",
    "Shipping Delay": "Shipping",
    "Safety Issue": "Safety",
    "Technical Problem": "Technical Support",
}
SLA = {"High": (1, 24), "Medium": (8, 72), "Low": (24, 168)}  # (first response h, resolution h)

RULES = []


def R(code, cat, sub, cond, urg, esc, refund, window, repl, comp, proof, policy, grp, A, B,
      approval=None, rel=""):
    if approval is None:
        approval = "Agent" if comp <= 10 else ("Manager" if comp <= 50 else "Admin")
    RULES.append(dict(code=code, category=cat, subcategory=sub, condition=cond, urgency=urg,
                      escalate=esc, refund=refund, window=window, replacement=repl, comp=comp,
                      proof=proof, policy=policy, group=grp, A=A, B=B, approval=approval, rel=rel))


DP, RF, BE, SD, SF, TP = ("Damaged Product", "Refund Request", "Billing Error",
                          "Shipping Delay", "Safety Issue", "Technical Problem")

# ------------------------------------------------------------------ DAMAGED PRODUCT (18)
R("D1", DP, "Damaged on arrival", "Reported within 7 days of delivery, photos provided",
  "Medium", "No", "Yes", 30, "Yes", 0, "Yes", "P04", "any",
  "Hello, my {p} from order {o} arrived yesterday with a cracked casing. I have attached photos of the damage. Could you please arrange a replacement or refund?",
  "{p} came broken today. photos attached. order {o}. need a replacement pls")
R("D2", DP, "Damaged on arrival", "Reported within 7 days of delivery, no photos provided",
  "Medium", "No", "Conditional", 30, "Conditional", 0, "Yes", "P04", "any",
  "Good afternoon, the {p} I received two days ago (order {o}) is damaged. I haven't taken any photos but the damage is obvious. Please send a replacement.",
  "my {p} is damaged, order {o}, got it 2 days ago, no pics sorry")
R("D3", DP, "Damaged on arrival", "Reported 8 to 30 days after delivery, photos provided",
  "Medium", "No", "Yes", 30, "Conditional", 0, "Yes", "P04", "any",
  "I received my {p} (order {o}) about three weeks ago and only just noticed a deep dent on the side. I have photos. Can I still return it for a refund?",
  "found a dent on my {p} from order {o}. got it 3 weeks ago. have photos. can i return it",
  rel="P01")
R("D4", DP, "Damaged on arrival", "Reported more than 30 days after delivery",
  "Low", "No", "No", "", "No", 0, "No", "P04", "any",
  "I bought a {p} (order {o}) about two months ago and I've just noticed a scratch and dent that must have happened in shipping. I would like a replacement.",
  "2 months ago i got my {p} order {o} and its dented. want a replacement")
R("D5", DP, "Cracked screen on arrival", "Reported within 7 days of delivery, photos provided",
  "Medium", "No", "Yes", 30, "Yes", 0, "Yes", "P04", "device",
  "The screen of my {p} was cracked when I opened the box yesterday (order {o}). I've uploaded photos of the crack. Please send a replacement.",
  "screen on my {p} is cracked out of the box. order {o}. pics attached")
R("D6", DP, "Damage caused by customer", "Customer admits dropping or mishandling the device",
  "Low", "No", "No", "", "No", 0, "No", "P04", "device",
  "I dropped my {p} (order {o}) last week and the screen cracked. Since it's fairly new, can you replace it for free?",
  "dropped my {p} and screen cracked. order {o}. can u replace it free", rel="P12")
R("D7", DP, "Damaged packaging only", "Item works; only the box is damaged",
  "Low", "No", "No", "", "No", 0, "No", "P04", "any",
  "The box for my {p} (order {o}) arrived crushed, but the product itself seems to work fine. I just wanted to report the packaging damage.",
  "box for {p} was crushed but item is ok. order {o}. just letting you know")
R("D8", DP, "Dead on arrival", "Device does not power on, within 30 days of delivery",
  "Medium", "No", "Yes", 30, "Yes", 0, "No", "P01", "device",
  "My new {p} (order {o}) will not turn on at all, even after charging it overnight. It arrived four days ago. I would like a replacement or my money back.",
  "{p} wont turn on. brand new. order {o}. want replacement or refund", rel="P13")
R("D9", DP, "Wrong item received", "Reported within 14 days of delivery",
  "Medium", "No", "Yes", 30, "Yes", 5, "Yes", "P05", "any",
  "I ordered a {p} (order {o}) but the package contained a completely different product. I've taken a photo of what I received. Please send me the correct item.",
  "got the wrong item in order {o}. i ordered {p}. photo attached")
R("D10", DP, "Wrong item received", "Reported more than 14 days after delivery",
  "Low", "No", "Conditional", 30, "Conditional", 0, "Yes", "P05", "any",
  "I received the wrong product in order {o} about a month ago instead of the {p} I ordered. I only just opened the box. Can you still fix this?",
  "opened box from order {o} today, wrong item inside, i ordered {p}. got it a month ago. can u still fix")
R("D11", DP, "Missing accessory", "Charger, cable or case missing, reported within 14 days",
  "Low", "No", "No", "", "Yes", 0, "No", "P05", "device",
  "My {p} (order {o}) arrived without the charging cable that was listed in the box contents. Could you please send the missing cable?",
  "no charging cable in the box of my {p}. order {o}")
R("D12", DP, "Missing item in multi-item order", "Item missing from parcel, reported within 14 days",
  "Medium", "No", "Conditional", 30, "Yes", 5, "Yes", "P05", "any",
  "I ordered three items in order {o} but only two arrived. The {p} is missing from the parcel. Please send it or refund that item.",
  "order {o} had 3 things but only 2 came. {p} is missing")
R("D13", DP, "Used or refurbished item sent as new", "Signs of prior use on an item sold as new",
  "Medium", "No", "Yes", 30, "Yes", 10, "Yes", "P05", "device",
  "The {p} from order {o} looks like it has been used before. There are fingerprints on the screen and the box was already opened. I paid for a new one and would like a new replacement.",
  "{p} from order {o} was clearly used. box was open and scratches on it. i paid for new")
R("D14", DP, "Damaged high-value item", "Damaged on arrival, order value above $1,000",
  "Medium", "Yes", "Yes", 30, "Yes", 0, "Yes", "P04", "big",
  "My {p} (order {o}) arrived with a bent frame and a broken corner. It was an expensive purchase and I have photos. I need this resolved properly, either a replacement or a refund.",
  "{p} arrived bent and broken, order {o}. it was over 1000 dollars. photos attached. fix this",
  approval="Manager", rel="P15")
R("D15", DP, "Damaged on arrival", "Customer wants replacement only, photos provided",
  "Medium", "No", "Yes", 30, "Yes", 0, "Yes", "P17", "any",
  "My {p} (order {o}) arrived damaged, and I have photos. I don't want a refund, I just want the same item replaced as soon as possible.",
  "{p} came damaged (order {o}). dont want refund just replace it. photos attached", rel="P04")
R("D16", DP, "Replacement also faulty", "Replacement item arrived damaged or faulty",
  "High", "Yes", "Yes", 30, "Conditional", 10, "Yes", "P17", "any",
  "This is the second time. The replacement {p} you sent for order {o} has also arrived damaged. I'm losing patience and would like a refund now.",
  "replacement {p} for order {o} is broken too. second one. just refund me", rel="P15")
R("D17", DP, "Replacement out of stock", "Damaged item, replacement unavailable",
  "Medium", "No", "Yes", 30, "Conditional", 0, "No", "P17", "any",
  "My {p} (order {o}) arrived damaged and the website now says the item is out of stock, so I can't get a replacement. What are my options?",
  "my {p} was damaged (order {o}) but its out of stock now. what can i do")
R("D18", DP, "Return label request", "Damaged item, customer asks for a return shipping label",
  "Low", "No", "Yes", 30, "Yes", 0, "No", "P04", "any",
  "My {p} (order {o}) is damaged and I'd like to send it back. Could you email me a prepaid return label, please? I don't want to pay for postage.",
  "need a return label for damaged {p}. order {o}. dont want to pay postage")

# ------------------------------------------------------------------ REFUND REQUEST (16)
R("R1", RF, "Standard refund", "Unused item, within 30 days of delivery",
  "Low", "No", "Yes", 30, "No", 0, "No", "P01", "any",
  "Hello, I'd like to return my {p} (order {o}). It is unused and still sealed, and I received it about two weeks ago. Please could you process a refund?",
  "want to return my {p} order {o}. never opened it. got it 2 weeks ago. refund pls")
R("R2", RF, "Standard refund", "Unused item, more than 30 days after delivery",
  "Low", "No", "No", "", "No", 0, "No", "P01", "any",
  "I bought a {p} (order {o}) about six weeks ago and never opened it. I've changed my mind and would like a refund.",
  "still have my {p} unopened from 6 weeks ago (order {o}). can i get refund")
R("R3", RF, "Opened non-defective item", "Within 15 days of delivery (15% restocking fee applies)",
  "Low", "No", "Conditional", 15, "No", 0, "No", "P01", "any",
  "I opened my {p} (order {o}) a week ago and decided it isn't what I need. It works fine. Can I return it for a refund?",
  "opened my {p} order {o} a week ago. works fine but i dont want it. can i return")
R("R4", RF, "Opened non-defective item", "16 to 30 days after delivery",
  "Low", "No", "No", "", "No", 0, "No", "P01", "any",
  "I've had my {p} (order {o}) for about three weeks. It works perfectly but I don't like it. I'd like to return it and get my money back.",
  "had {p} 3 weeks (order {o}). dont like it. want money back")
R("R5", RF, "Defective item", "Faulty within 30 days, troubleshooting already tried",
  "Medium", "No", "Yes", 30, "Yes", 0, "No", "P01", "device",
  "My {p} (order {o}) developed a fault after ten days: it keeps shutting down randomly, even after I reset it and updated the software. I'd like to return it for a refund.",
  "{p} keeps shutting off by itself even after reset. order {o}. 10 days old. i want refund", rel="P13")
R("R6", RF, "Defective item after return window", "Fault after 30 days, within 12-month warranty",
  "Medium", "No", "No", "", "Conditional", 0, "No", "P12", "device",
  "My {p} (order {o}) stopped charging after four months. I want a refund since it's clearly defective.",
  "{p} died after 4 months. order {o}. i want my money back", rel="P01")
R("R7", RF, "Refund status enquiry", "Refund approved, within 7 business days",
  "Low", "No", "Yes", "", "No", 0, "No", "P01", "any",
  "Hi, I returned my {p} (order {o}) last week and was told a refund had been approved. When will the money arrive?",
  "refund for order {o} approved 3 days ago. when do i get the money")
R("R8", RF, "Refund delayed", "Approved refund not received after 10 business days",
  "Medium", "No", "Yes", "", "No", 5, "No", "P01", "any",
  "My refund for order {o} ({p}) was approved more than two weeks ago and there is still no money in my account. Please look into this.",
  "refund for {p} order {o} still not here. approved 2 weeks ago", rel="P14")
R("R9", RF, "Refund to different method", "Customer asks for refund to another card or account",
  "Low", "No", "No", "", "No", 0, "No", "P01", "any",
  "I paid for order {o} with a card that has since been cancelled. Could you refund the {p} to my new card or my bank account instead?",
  "old card is closed. refund {p} order {o} to my other card")
R("R10", RF, "Gift purchase", "Gift recipient (not the buyer) requests a return",
  "Low", "No", "Conditional", 30, "No", 0, "No", "P01", "any",
  "I received a {p} as a gift (order {o}) and it doesn't suit me. I don't have the payment details because someone else bought it. How can I return it?",
  "got {p} as a gift. order {o}. dont want it. how to return? i didnt buy it")
R("R11", RF, "Non-refundable item", "Gift card or digital product",
  "Low", "No", "No", "", "No", 0, "No", "P01", "giftcard",
  "I bought a {p} (order {o}) by mistake. Could you cancel it and refund me?",
  "bought a {p} by mistake order {o}. refund pls")
R("R12", RF, "Clearance item", "Final-sale item, not defective",
  "Low", "No", "No", "", "No", 0, "No", "P01", "any",
  "I bought a {p} from the clearance section (order {o}) and now I want to return it. It's unopened. Is that possible?",
  "bought {p} on clearance order {o}. want to return it. unopened")
R("R13", RF, "Cash compensation demand", "Customer demands cash on top of a valid refund",
  "Medium", "No", "Yes", 30, "No", 0, "No", "P14", "any",
  "I'm returning my {p} from order {o} for a refund, which is fine, but I also want $30 paid to me in cash for the hassle. I bought it last week.",
  "returning {p} order {o}. bought last week. want refund and $30 cash for the trouble", rel="P01")
R("R14", RF, "Compensation above authority", "Customer demands more than $50 compensation",
  "Medium", "Yes", "Conditional", 30, "No", 50, "No", "P14", "any",
  "My {p} (order {o}) caused me a lot of trouble and I've wasted hours on this. I expect at least $300 in compensation on top of a refund.",
  "{p} order {o} was a nightmare. i want 300 dollars compensation plus refund",
  approval="Manager", rel="P15")
R("R15", RF, "Partial return", "One item from a multi-item order, within 30 days",
  "Low", "No", "Yes", 30, "No", 0, "No", "P01", "any",
  "I ordered several items in order {o} and would like to return only the {p}. It is unused. Can you refund just that item?",
  "want to return just the {p} from order {o}. unused. refund that one only")
R("R16", RF, "Chargeback filed", "Customer has opened a bank dispute",
  "Medium", "Yes", "No", "", "No", 0, "No", "P09", "any",
  "I've already filed a dispute with my bank over order {o} ({p}) because I still haven't got my refund. I wanted to let you know.",
  "i opened a chargeback with my bank for order {o}. no refund for {p}", rel="P15")

# ------------------------------------------------------------------ BILLING ERROR (16)
R("B1", BE, "Duplicate charge", "Charged twice for the same order, within 60 days",
  "Medium", "No", "Yes", 60, "No", 0, "No", "P09", "any",
  "I was charged twice for order {o} ({p}). Two identical payments appear on my bank statement from yesterday. Please refund the duplicate.",
  "charged twice for order {o}. same amount two times. refund one")
R("B2", BE, "Duplicate charge unresolved", "Duplicate charge still not refunded after 5 business days",
  "High", "No", "Yes", 60, "No", 5, "No", "P09", "any",
  "I reported a double charge on order {o} a week ago and I was told it would be fixed in a few days. The extra payment for the {p} is still on my account.",
  "reported double charge on order {o} a week ago. still not refunded")
R("B3", BE, "Wrong amount charged", "Charged more than the listed price",
  "Medium", "No", "Yes", 60, "No", 0, "No", "P09", "any",
  "The website showed the {p} at a lower price than what I was charged on order {o}. I'd like the difference refunded.",
  "charged more than the listed price for {p} order {o}. want difference back")
R("B4", BE, "Charged after cancellation", "Order cancelled but payment still taken",
  "Medium", "No", "Yes", 60, "No", 0, "No", "P18", "any",
  "I cancelled order {o} ({p}) before it shipped, and I received a confirmation, but I've still been charged. Please refund me.",
  "cancelled order {o} but got charged anyway")
R("B5", BE, "Payment failed but money taken", "Error shown at checkout, amount deducted, no order",
  "Medium", "No", "Yes", "", "No", 0, "No", "P10", "any",
  "My payment for the {p} failed on the checkout page, but the money left my account and I have no order confirmation.",
  "payment failed on site but money came out of my account. no order for {p}")
R("B6", BE, "Pending authorization hold", "Bank hold not yet released",
  "Low", "No", "No", "", "No", 0, "No", "P10", "any",
  "There is a pending charge from VoltCart on my card for order {o} which I cancelled last week. It hasn't dropped off yet. Can you release it?",
  "pending charge from you guys still on my card. order {o}, cancelled it last week")
R("B7", BE, "Unrecognised charge", "Customer does not recognise a VoltCart charge",
  "High", "Yes", "Conditional", 60, "No", 0, "No", "P09", "any",
  "There is a charge from VoltCart on my statement that I don't recognise. I haven't ordered anything recently. Please tell me what it is.",
  "i see a charge from voltcart i dont recognise. i didnt order anything", rel="P15")
R("B8", BE, "Suspected fraud", "Customer says their card was used without permission",
  "High", "Yes", "Conditional", 60, "No", 0, "No", "P09", "any",
  "Someone has used my card to place an order with VoltCart (order {o}) without my permission. I want the order stopped and the charge reversed immediately.",
  "someone used my card on your site. order {o}. not me! stop it and refund", rel="P15")
R("B9", BE, "Wrong tax or shipping fee", "Shipping fee charged on an order that qualified for free shipping",
  "Low", "No", "Yes", 60, "No", 0, "No", "P09", "any",
  "I was charged shipping on order {o} even though the page said free delivery for orders over $100. Could you refund the shipping fee?",
  "charged shipping on order {o} but it said free shipping. refund it", rel="P06")
R("B10", BE, "Promo code not applied", "Valid promo code did not apply at checkout",
  "Low", "No", "Conditional", 14, "No", 0, "No", "P20", "any",
  "I entered a valid promo code on order {o} but the discount wasn't applied to my {p}. Could you adjust the price?",
  "my promo code didnt work on order {o}. got no discount. can u fix")
R("B11", BE, "Price adjustment", "Price dropped within 14 days of purchase",
  "Low", "No", "Yes", 14, "No", 0, "No", "P20", "any",
  "I bought the {p} (order {o}) five days ago and the price has now dropped. Can I get the difference refunded?",
  "price of {p} dropped 5 days after i bought it. order {o}. want difference")
R("B12", BE, "Price adjustment", "Price dropped more than 14 days after purchase",
  "Low", "No", "No", "", "No", 0, "No", "P20", "any",
  "I bought the {p} (order {o}) about a month ago and I noticed it's cheaper now. Could you refund me the price difference?",
  "{p} is cheaper now than a month ago when i bought it. order {o}. give me the difference")
R("B13", BE, "Invoice or receipt request", "Customer needs a document, not a refund",
  "Low", "No", "N/A", "", "N/A", 0, "No", "P09", "any",
  "Could you please send me a PDF invoice for order {o}? I need it for my company's expenses.",
  "need invoice for order {o} pls")
R("B14", BE, "Extended warranty charged without consent", "Warranty add-on the customer did not choose",
  "Medium", "No", "Yes", 60, "No", 0, "No", "P09", "any",
  "I was charged for an extended warranty on order {o} that I never chose. I'd like it removed and the money returned.",
  "extended warranty added to order {o} and i didnt pick it. refund that", rel="P12")
R("B15", BE, "Currency conversion or bank fee", "Fee charged by the customer's bank",
  "Low", "No", "No", "", "No", 0, "No", "P09", "any",
  "My bank added a foreign transaction fee to order {o}. Can VoltCart refund that fee?",
  "bank charged me extra fee on order {o}. can you refund the fee")
R("B16", BE, "Billing dispute with legal threat", "Overcharge unresolved, customer threatens legal action",
  "High", "Yes", "Conditional", "", "No", 0, "No", "P15", "any",
  "I've been overcharged on order {o} and no one is resolving it. If this isn't fixed this week I'll be speaking to my solicitor about taking legal action.",
  "overcharged on order {o}. fix it or ill take you to court", rel="P09")

# ------------------------------------------------------------------ SHIPPING DELAY (16)
R("S1", SD, "Order in transit", "Still within the estimated delivery window",
  "Low", "No", "No", "", "No", 0, "No", "P06", "any",
  "I placed order {o} ({p}) three days ago and haven't received any tracking updates yet. Is it on its way?",
  "where is my order {o}? ordered 3 days ago. no tracking update")
R("S2", SD, "Late delivery", "1 to 7 business days past the estimated date",
  "Low", "No", "No", "", "No", 0, "No", "P07", "any",
  "My order {o} was supposed to arrive on Monday, but it's now Thursday and it still hasn't come. Can you check where my {p} is?",
  "order {o} is 3 days late. where is it")
R("S3", SD, "Late delivery", "8 to 14 business days past the estimated date",
  "Medium", "No", "Conditional", 30, "No", 5, "No", "P07", "any",
  "My order {o} ({p}) is now almost two weeks past the delivery date I was given. This is very disappointing. I would like to know what happens next.",
  "order {o} is nearly 2 weeks late. what are you going to do about it")
R("S4", SD, "Late delivery", "More than 14 business days past the estimated date",
  "High", "No", "Yes", 30, "Yes", 10, "No", "P07", "any",
  "My {p} (order {o}) is now more than three weeks late. No one has given me a proper explanation. I want either the item immediately or my money back.",
  "order {o} 3+ weeks late! item or refund now", rel="P08")
R("S5", SD, "Tracking not updating", "No tracking movement for 5 or more days",
  "Medium", "No", "No", "", "No", 0, "No", "P06", "any",
  "The tracking for order {o} hasn't changed in six days. It still says the package is at a depot. Can you find out what's happening?",
  "tracking stuck for 6 days on order {o}")
R("S6", SD, "Marked delivered but not received", "Tracking shows delivered, customer has nothing",
  "Medium", "No", "Conditional", 30, "Conditional", 0, "No", "P08", "any",
  "The tracking for order {o} says delivered yesterday, but nothing arrived and I've checked with my neighbours. Where is my {p}?",
  "order {o} says delivered but i got nothing. checked with neighbours")
R("S7", SD, "Lost in transit", "Carrier confirms the package is lost",
  "Medium", "No", "Yes", 30, "Yes", 10, "No", "P08", "any",
  "The courier told me my parcel for order {o} has been lost. Could you send a new {p} or refund me?",
  "courier says my parcel was lost. order {o}. need replacement or refund")
R("S8", SD, "Package stolen after delivery", "Delivery confirmed, then stolen from the doorstep",
  "Medium", "No", "Conditional", 30, "Conditional", 0, "No", "P08", "any",
  "Order {o} was delivered to my doorstep, but the package was stolen a few hours later. I have a police report. Can VoltCart do anything?",
  "package for order {o} got stolen from my door after delivery. what now")
R("S9", SD, "Wrong address entered by customer", "Order delivered to the address the customer typed",
  "Low", "No", "No", "", "No", 0, "No", "P06", "any",
  "I made a mistake and typed the wrong house number on order {o}, and the parcel has already been delivered there. Can you resend the {p} for free?",
  "put wrong address on order {o}. it was delivered there. send again free")
R("S10", SD, "Address change request", "Order not yet shipped",
  "Low", "No", "N/A", "", "N/A", 0, "No", "P06", "any",
  "I've moved house since placing order {o}. Can I change the delivery address before it ships?",
  "need to change address on order {o} before it ships")
R("S11", SD, "Express delivery late", "Express order arrived more than 2 business days after dispatch",
  "Medium", "No", "Yes", 30, "No", 5, "No", "P06", "any",
  "I paid extra for express delivery on order {o}, which promised 1 to 2 days, but it took 5 days to arrive. I'd like the express fee refunded.",
  "paid for express shipping on order {o} but took 5 days. refund the fee", rel="P07")
R("S12", SD, "Order stuck in processing", "Not dispatched after 3 business days",
  "Medium", "No", "Conditional", 30, "No", 0, "No", "P06", "any",
  "Order {o} ({p}) has been showing as processing for five days and hasn't shipped. Can you tell me what's wrong?",
  "order {o} says processing for 5 days. when will it ship")
R("S13", SD, "Partial shipment", "Order split into parcels, second parcel delayed",
  "Low", "No", "Conditional", 30, "No", 0, "No", "P06", "any",
  "Order {o} was split into two shipments. The first arrived, but the tracking for the second parcel with the {p} hasn't moved.",
  "only got part of order {o}. {p} shipped separately and tracking not moving")
R("S14", SD, "Customs delay", "International order held by customs",
  "Low", "No", "No", "", "No", 0, "No", "P06", "any",
  "My international order {o} has been held at customs for a week. Can VoltCart speed this up?",
  "order {o} stuck in customs for a week. help")
R("S15", SD, "Missed delivery attempt", "Courier failed to deliver or left a card",
  "Low", "No", "No", "", "No", 0, "No", "P06", "any",
  "The courier left a 'missed delivery' card for order {o}, but I was home all day. Can you arrange for redelivery?",
  "courier said i missed delivery but i was home. order {o}. redeliver pls")
R("S16", SD, "Time-critical delivery delayed", "Customer needs the item for a specific event date",
  "Medium", "No", "Conditional", 30, "No", 5, "No", "P07", "any",
  "I bought the {p} (order {o}) as a birthday gift for this Saturday, but it's already late and I'm running out of time. Can you speed this up or cancel it?",
  "{p} order {o} was a birthday gift for saturday. still not here. help")

# ------------------------------------------------------------------ SAFETY ISSUE (16)
R("F1", SF, "Overheating", "Device or charger gets dangerously hot",
  "High", "Yes", "Yes", "Any", "No", 50, "No", "P11", "hot",
  "My {p} (order {o}) gets extremely hot while charging, too hot to touch. I have stopped using it. What should I do?",
  "{p} is burning hot when charging. too hot to touch. order {o}")
R("F2", SF, "Smoke or fire", "Smoke or flames from the device",
  "High", "Yes", "Yes", "Any", "No", 50, "No", "P11", "hot",
  "My {p} started smoking while it was plugged in (order {o}). I unplugged it straight away. This is dangerous and I want to report it.",
  "{p} caught fire! order {o}. smoke everywhere. unplugged it")
R("F3", SF, "Battery swelling", "Battery bulging or pushing the case apart",
  "High", "Yes", "Yes", "Any", "No", 50, "No", "P11", "batt",
  "The battery in my {p} (order {o}) has swollen and is pushing the case apart. I've stopped using it. What do I do?",
  "{p} battery is bulging. case is coming apart. order {o}")
R("F4", SF, "Electric shock", "Customer received an electric shock",
  "High", "Yes", "Yes", "Any", "No", 50, "No", "P11", "chargeonly",
  "I got an electric shock when I touched my {p} (order {o}) while it was plugged in. It really hurt. I've stopped using it.",
  "got a shock from my {p}. order {o}. not using it again")
R("F5", SF, "Physical injury", "Customer was injured by the device",
  "High", "Yes", "Yes", "Any", "No", 100, "No", "P11", "hot",
  "My {p} (order {o}) overheated and burned my hand. I needed treatment at a clinic. I expect VoltCart to take responsibility.",
  "{p} burned my hand. order {o}. had to go to a clinic", rel="P15")
R("F6", SF, "Property damage caused by device", "Device damaged the customer's property",
  "High", "Yes", "Yes", "Any", "No", 100, "No", "P11", "hot",
  "The {p} (order {o}) set fire to my desk and scorched the wall. I have photos of the damage. Who is going to pay for this?",
  "{p} burned my desk and wall. order {o}. photos attached. who pays", rel="P15")
R("F7", SF, "Product recall enquiry", "Customer asks whether their product is recalled",
  "Medium", "No", "Yes", "Any", "Yes", 0, "No", "P11", "charge",
  "I saw a news report about a recall on VoltCart chargers. Is my {p} (order {o}) affected, and how do I get it replaced or refunded?",
  "is my {p} part of the recall? order {o}. how do i return it")
R("F8", SF, "Child safety", "Child chewed, swallowed or handled a dangerous part",
  "High", "Yes", "Yes", "Any", "No", 50, "No", "P11", "small",
  "My toddler chewed on the {p} (order {o}) and part of it came off. I'm very worried. What should I do?",
  "my kid bit my {p} and a piece came off. order {o}. is it safe")
R("F9", SF, "Suspected counterfeit or unsafe accessory", "No safety markings, product looks fake",
  "Medium", "Yes", "Yes", "Any", "Yes", 0, "No", "P11", "charge",
  "The {p} I received (order {o}) has no safety markings and the plug looks fake. I'm worried it's counterfeit and unsafe. Can you check?",
  "{p} order {o} looks fake. no safety mark on it. is it real")
R("F10", SF, "Burning smell", "Smell only, no visible smoke or fire",
  "High", "Yes", "Yes", "Any", "No", 20, "No", "P11", "hot",
  "My {p} (order {o}) gives off a strong burning smell when I use it. I've switched it off. Is this dangerous?",
  "{p} smells like burning. order {o}. turned it off")
R("F11", SF, "Sparking", "Sparks when plugged into a socket",
  "High", "Yes", "Yes", "Any", "No", 50, "No", "P11", "chargeonly",
  "The {p} (order {o}) sparked when I plugged it into the wall socket and the socket tripped. I'm concerned about using it again.",
  "{p} sparked in the socket. order {o}. scary")
R("F12", SF, "Warm during normal use", "Mildly warm only, no smell, smoke or swelling",
  "Medium", "No", "Conditional", 30, "Conditional", 0, "No", "P11", "device",
  "My {p} (order {o}) gets quite warm when I use it, but not hot and there's no smell or smoke. Is that normal?",
  "my {p} gets warm when using it. order {o}. normal?", rel="P13")
R("F13", SF, "Safety complaint with media threat", "Hazard reported, customer threatens to go to the media",
  "High", "Yes", "Yes", "Any", "No", 50, "No", "P11", "hot",
  "My {p} (order {o}) overheated and nearly caused a fire. If VoltCart doesn't respond properly I'll post the whole story and the photos on social media and contact the local news.",
  "{p} overheated order {o}. if u dont fix ill post it on social media and tell the news", rel="P15")
R("F14", SF, "Safety complaint with legal threat", "Hazard and property damage, customer threatens legal action",
  "High", "Yes", "Yes", "Any", "No", 100, "No", "P11", "hot",
  "My {p} (order {o}) overheated and damaged my property. I've already spoken to a solicitor and will pursue legal action unless VoltCart responds.",
  "{p} order {o} overheated and damaged my stuff. talking to a lawyer", rel="P15")
R("F15", SF, "Second safety incident", "Replacement device also overheated",
  "High", "Yes", "Yes", "Any", "No", 100, "No", "P11", "hot",
  "The replacement {p} you sent for order {o} has overheated as well. This is the second dangerous device from VoltCart. I'm not using anything else.",
  "replacement {p} order {o} overheated too. second time. this is not ok", rel="P17")
R("F16", SF, "Explosion or loud pop", "Loud bang or hissing while charging",
  "High", "Yes", "Yes", "Any", "No", 100, "No", "P11", "batt",
  "My {p} (order {o}) made a loud bang and started hissing while charging. Nobody was hurt but it was frightening. I've disconnected everything.",
  "{p} exploded with a loud bang while charging. order {o}")

# ------------------------------------------------------------------ TECHNICAL PROBLEM (18)
R("T1", TP, "Stopped working within 30 days", "Customer asks for troubleshooting help",
  "Medium", "No", "Conditional", 30, "Conditional", 0, "No", "P13", "device",
  "My {p} (order {o}) stopped responding after two weeks. It just shows a black screen. Can you help me get it working?",
  "{p} black screen since yesterday. 2 weeks old. order {o}. help")
R("T2", TP, "Stopped working 31 days to 12 months", "Within the 12-month warranty period",
  "Medium", "No", "No", "", "Yes", 0, "Yes", "P12", "device",
  "My {p} (order {o}) stopped working after seven months. I know it's out of the return period but it should still be under warranty. What can I do?",
  "{p} died after 7 months. order {o}. under warranty right")
R("T3", TP, "Stopped working after warranty", "More than 12 months after delivery",
  "Low", "No", "No", "", "No", 0, "No", "P12", "device",
  "My {p} (order {o}) stopped working after about 18 months. Is there any way you can help with a repair or a discount?",
  "{p} stopped working after 18 months. order {o}. any discount for repair")
R("T4", TP, "Water or liquid damage", "Liquid damage caused by the customer",
  "Low", "No", "No", "", "No", 0, "No", "P12", "device",
  "I accidentally spilled water on my {p} (order {o}) and now it won't work. Will the warranty cover it?",
  "spilled water on my {p}. order {o}. warranty cover it")
R("T5", TP, "Battery drains quickly", "Battery health problem within 12 months",
  "Low", "No", "No", "", "Conditional", 0, "No", "P12", "devbuds",
  "The battery on my {p} (order {o}) drains in a couple of hours since about five months ago. Can this be fixed under warranty?",
  "{p} battery dies in 2 hours now. order {o}. 5 months old")
R("T6", TP, "Bluetooth or pairing problem", "Connectivity issue, standard steps not yet exhausted",
  "Low", "No", "No", "", "No", 0, "No", "P13", "audiowatch",
  "My {p} (order {o}) won't pair with my phone over Bluetooth, even after resetting it and trying again several times. Any other ideas?",
  "{p} wont connect to bluetooth. order {o}. tried resetting")
R("T7", TP, "Software or firmware problem", "Restarts or bugs after an update",
  "Low", "No", "No", "", "No", 0, "No", "P13", "device",
  "Since the latest firmware update, my {p} (order {o}) keeps restarting. Is there a fix or a way to roll back?",
  "{p} restarts by itself after update. order {o}")
R("T8", TP, "Setup or how-to question", "Customer needs instructions",
  "Low", "No", "N/A", "", "N/A", 0, "No", "P13", "any",
  "I've just received my {p} (order {o}) and I'm not sure how to set it up. Do you have a guide?",
  "how do i set up my {p}. order {o}")
R("T9", TP, "Charging problem", "Charger or cable stopped charging within 30 days",
  "Medium", "No", "Conditional", 30, "Conditional", 0, "No", "P13", "charge",
  "My {p} (order {o}) stopped charging my phone after a week. I've tried different sockets and cables. Please help.",
  "{p} not charging anything since last week. order {o}. tried other sockets")
R("T10", TP, "Screen flickering or dead pixels", "Display defect within 30 days",
  "Medium", "No", "Yes", 30, "Yes", 0, "No", "P13", "device",
  "The screen on my {p} (order {o}) flickers constantly and has a line of dead pixels. It's only ten days old. I'd like it replaced.",
  "{p} screen flickers and has dead pixels. order {o}. 10 days old. replace it")
R("T11", TP, "One earbud not working", "Audio defect within 30 days",
  "Medium", "No", "Yes", 30, "Yes", 0, "No", "P13", "buds",
  "The left earbud on my {p} (order {o}) stopped working after nine days. I've tried resetting and re-pairing. Can you replace them?",
  "left earbud dead on my {p}. order {o}. 9 days old. tried reset")
R("T12", TP, "Laptop crashing", "Repeated crashes within 30 days",
  "Medium", "No", "Conditional", 30, "Conditional", 0, "No", "P13", "laptop",
  "My {p} (order {o}) keeps crashing with a blue screen several times a day. I've done a full reset. Is this a hardware fault?",
  "{p} blue screens all the time. order {o}. did factory reset")
R("T13", TP, "Unresolved after 3 or more contacts", "Same problem reported three or more times",
  "High", "Yes", "Conditional", 30, "Yes", 0, "No", "P15", "device",
  "This is my fourth time contacting you about my {p} (order {o}). Every reply repeats the same troubleshooting steps, and the problem is still there. Please escalate this.",
  "4th time contacting you about {p} order {o}. still not fixed. escalate this", rel="P13")
R("T14", TP, "App or account login problem", "Cannot sign in to VoltCart account or app",
  "Low", "No", "N/A", "", "N/A", 0, "No", "P13", "app",
  "I can't log in to my VoltCart account or the VoltCart app. The password reset email never arrives.",
  "cant login to my account. reset email not coming")
R("T15", TP, "Product not compatible", "Opened, not faulty, within 15 days (restocking fee applies)",
  "Low", "No", "Conditional", 15, "No", 0, "No", "P01", "any",
  "I bought the {p} (order {o}) but it isn't compatible with my old laptop. I opened it but haven't really used it. Can I return it?",
  "{p} doesnt work with my laptop. order {o}. opened it but not used. can i return", rel="P13")
R("T16", TP, "Data loss on device", "Data lost after a software update",
  "Medium", "No", "No", "", "No", 0, "No", "P13", "device",
  "After a software update my {p} (order {o}) lost all my saved data and settings. Can VoltCart recover it or compensate me?",
  "lost all my data on {p} after update. order {o}. can u get it back")
R("T17", TP, "Warranty claim without proof of purchase", "No order number or receipt available",
  "Low", "No", "No", "", "Conditional", 0, "Yes", "P12", "any",
  "My {p} is under a year old and has stopped working. I bought it from VoltCart but I can't find my order number or receipt. Can I still claim under warranty?",
  "{p} broke. i lost my receipt and cant find order number. warranty still valid?")
R("T18", TP, "Repair status enquiry", "Customer asks about a warranty repair in progress",
  "Low", "No", "N/A", "", "N/A", 0, "No", "P12", "device",
  "I sent my {p} (order {o}) for a warranty repair two weeks ago. Do you have any update on its status?",
  "any update on repair of my {p}? order {o}. sent 2 weeks ago")

assert len(RULES) == 100, len(RULES)
for i, r in enumerate(RULES, 1):
    r["rule_id"] = f"R{i:03d}"
    r["department"] = DEPT[r["category"]]
BY_CODE = {r["code"]: r for r in RULES}
assert len(BY_CODE) == 100
