import csv, json
from rules_data import RULES, SLA
from policies_data import P

# ---------------- rule matrix
cols = ["rule_id","category","subcategory","condition","department","urgency","escalate","refund_allowed",
        "refund_window_days","replacement_allowed","max_compensation_usd","compensation_type","approval_level",
        "proof_required","sla_first_response_hours","sla_resolution_hours","policy_id","related_policy_ids"]
with open("out/rule_matrix.csv","w",newline="",encoding="utf-8") as f:
    w = csv.writer(f); w.writerow(cols)
    for r in RULES:
        fr, res = SLA[r["urgency"]]
        w.writerow([r["rule_id"], r["category"], r["subcategory"], r["condition"], r["department"], r["urgency"],
                    r["escalate"], r["refund"], r["window"], r["replacement"], r["comp"],
                    "Store credit" if r["comp"] > 0 else "None", r["approval"], r["proof"], fr, res,
                    r["policy"], r["rel"]])
print("rules:", len(RULES))

# ---------------- policy registry
LEVEL = {1:"Safety (highest)", 2:"Compliance and authority limits", 3:"Specific operational policy", 4:"General policy"}
def fname(p): return f"{p['id']}_{p['title'].replace(' ','_').replace(',','')}_v{p['version']}.{p['fmt']}"
with open("out/policy_registry.csv","w",newline="",encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["policy_id","title","version","status","effective_date","supersedes","precedence_level",
                "precedence_label","owner_department","file_name","file_format"])
    for p in P:
        w.writerow([p["id"],p["title"],p["version"],p["status"],p["effective"],p["supersedes"],p["precedence"],
                    LEVEL[p["precedence"]],p["owner"],fname(p),p["fmt"]])
for p in P: p["file_name"] = fname(p)
json.dump(P, open("policies.json","w"), indent=1)
print("policies:", len(P))
