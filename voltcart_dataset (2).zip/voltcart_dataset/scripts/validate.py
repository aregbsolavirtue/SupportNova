import csv, collections, os, json
rules = list(csv.DictReader(open("out/rule_matrix.csv", encoding="utf-8")))
comps = list(csv.DictReader(open("out/complaints.csv", encoding="utf-8")))
reg = {r["policy_id"]: r for r in csv.DictReader(open("out/policy_registry.csv", encoding="utf-8"))}
R = {r["rule_id"]: r for r in rules}
errs = []

# rules
assert len(rules) == 100 and len(R) == 100
for r in rules:
    for pid in [r["policy_id"]] + [x for x in r["related_policy_ids"].split(";") if x]:
        if pid not in reg: errs.append(f"{r['rule_id']} unknown policy {pid}")
        elif reg[pid]["status"] != "Active": errs.append(f"{r['rule_id']} points to non-active {pid}")
    if r["urgency"] == "High" and r["sla_first_response_hours"] != "1": errs.append(f"{r['rule_id']} SLA")
print("rules by category:", dict(collections.Counter(r["category"] for r in rules)))
print("rules by urgency :", dict(collections.Counter(r["urgency"] for r in rules)))
print("policies by status:", dict(collections.Counter(p["status"] for p in reg.values())))

# complaints
assert len(comps) == 500
ids = {c["complaint_id"] for c in comps}; assert len(ids) == 500
C = {c["complaint_id"]: c for c in comps}
print("\ncomplaints by type:", dict(collections.Counter(c["complaint_type"] for c in comps)))
per_rule = collections.Counter(c["expected_rule_id"] for c in comps if c["expected_rule_id"])
print("min/max complaints per rule:", min(per_rule.values()), max(per_rule.values()), "| rules covered:", len(per_rule))
for c in comps:
    if "{" in c["complaint_text"] or "}" in c["complaint_text"]: errs.append(f"{c['complaint_id']} placeholder left")
    rid = c["expected_rule_id"]
    if rid:
        if rid not in R: errs.append(f"{c['complaint_id']} bad rule {rid}"); continue
        r = R[rid]
        checks = [("expected_category","category"),("expected_department","department"),("expected_urgency","urgency"),
                  ("expected_refund_allowed","refund_allowed"),("expected_max_compensation_usd","max_compensation_usd"),
                  ("expected_policy_id","policy_id")]
        for ck, rk in checks:
            if c[ck] != r[rk]: errs.append(f"{c['complaint_id']} {ck} {c[ck]} != rule {r[rk]}")
        if c["expected_escalation"] != r["escalate"] and c["complaint_type"] != "repeat_followup":
            errs.append(f"{c['complaint_id']} escalation mismatch")
    if c["duplicate_of"]:
        o = C[c["duplicate_of"]]
        if (o["customer_id"], o["order_id"]) != (c["customer_id"], c["order_id"]): errs.append(f"{c['complaint_id']} dup mismatch")
        if o["submitted_at"] >= c["submitted_at"]: errs.append(f"{c['complaint_id']} dup earlier than original")
    hv = float(c["order_value_usd"]) > 1000
    if hv and c["expected_rule_id"] != "R014": errs.append(f"{c['complaint_id']} high value but not D14 rule")
    if c["expected_rule_id"] == "R014" and not hv: errs.append(f"{c['complaint_id']} D14 not high value")
print("escalate=Yes share of complaints:", sum(c["expected_escalation"]=="Yes" for c in comps), "/ 500")

# policy files
files = os.listdir("out/policies"); assert len(files) == 20
for p in reg.values(): assert p["file_name"] in files, p["file_name"]
print("policy files:", collections.Counter(f.rsplit(".",1)[1] for f in files))
print("\nERRORS:", len(errs)); [print(" ", e) for e in errs[:20]]
