import json
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from xml.sax.saxutils import escape

P = json.load(open("policies.json"))
ss = getSampleStyleSheet()
title = ParagraphStyle("t", parent=ss["Title"], fontName="Helvetica-Bold", fontSize=22, alignment=0, spaceAfter=10)
small = ParagraphStyle("s", parent=ss["Normal"], fontName="Helvetica", fontSize=9, textColor=colors.grey)
h1 = ParagraphStyle("h", parent=ss["Heading1"], fontName="Helvetica-Bold", fontSize=13, textColor=colors.HexColor("#1F3A5F"), spaceBefore=14, spaceAfter=6)
body = ParagraphStyle("b", parent=ss["Normal"], fontName="Helvetica", fontSize=10.5, leading=14, spaceAfter=5)
clause = ParagraphStyle("c", parent=body, leftIndent=28, firstLineIndent=-28)
banner = ParagraphStyle("bn", parent=body, fontName="Helvetica-Bold", textColor=colors.HexColor("#B00020"), backColor=colors.HexColor("#FDECEA"), borderPadding=6, spaceAfter=12)

for p in [x for x in P if x["fmt"] == "pdf"]:
    def foot(c, d, p=p):
        c.saveState(); c.setFont("Helvetica", 8); c.setFillColor(colors.grey)
        c.drawString(72, 40, f"{p['id']} | v{p['version']} | {p['status']} | VoltCart (fictional company)")
        c.drawRightString(540, 40, f"Page {d.page}"); c.restoreState()
    doc = SimpleDocTemplate(f"out/policies/{p['file_name']}", pagesize=letter, leftMargin=72, rightMargin=72,
                            topMargin=64, bottomMargin=64, title=f"{p['title']} v{p['version']}", author="VoltCart")
    s = [Paragraph("VoltCart Internal Policy", small), Paragraph(escape(p["title"]), title)]
    if p["banner"]:
        s.append(Paragraph(escape(p["banner"]), banner))
    meta = [["Policy ID", p["id"]], ["Version", p["version"]], ["Status", p["status"]],
            ["Effective date", p["effective"]], ["Supersedes", p["supersedes"] or "None"],
            ["Owner", p["owner"] + " team"], ["Precedence level", str(p["precedence"])]]
    t = Table(meta, colWidths=[110, 358])
    t.setStyle(TableStyle([("FONTNAME", (0,0), (0,-1), "Helvetica-Bold"), ("FONTNAME", (1,0), (1,-1), "Helvetica"),
        ("FONTSIZE", (0,0), (-1,-1), 9.5), ("GRID", (0,0), (-1,-1), 0.5, colors.HexColor("#BBBBBB")),
        ("BACKGROUND", (0,0), (0,-1), colors.HexColor("#EEF2F7")), ("TOPPADDING", (0,0), (-1,-1), 4), ("BOTTOMPADDING", (0,0), (-1,-1), 4)]))
    s += [t, Paragraph("Purpose", h1), Paragraph(escape(p["purpose"]), body)]
    for si, (head, cl) in enumerate(p["sections"], 1):
        s.append(Paragraph(f"{si}. {escape(head)}", h1))
        for ci, c in enumerate(cl, 1):
            s.append(Paragraph(f"<b>{si}.{ci}</b>&nbsp;&nbsp;&nbsp;{escape(c)}", clause))
    doc.build(s, onFirstPage=foot, onLaterPages=foot)
print("pdfs done")
