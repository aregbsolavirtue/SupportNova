# Policy Precedence Guide (for Ajoke's retrieval and precedence logic)

The file `policy_registry.csv` has a `status` and a `precedence_level` for every policy.
Apply these rules **in this order** when several policies match a complaint:

1. **Status first.** Only `Active` policies apply. `Old` and `Draft` policies never apply to a new complaint, even if they match better.
2. **Safety wins.** Level 1 (P11 Safety Incident Policy) overrides every other policy.
3. **Authority limits cap everything.** Level 2 policies (P14 Compensation, P15 Escalation, P19 Communication) limit what any other policy can offer or say.
4. **Specific beats general.** Level 3 (specific policies) beat Level 4 (general policies such as P01 Refund and P16 SLA).
5. **Same level:** the policy with the newer `effective_date` wins. Higher version of the same policy wins.
6. **Still unclear?** Send the case to manual review. Do not guess.

## Built-in conflicts in this dataset (use these as test cases)

| Situation | Conflicting policies | Correct winner |
|---|---|---|
| Refund window: 14 days vs 30 days vs 45 days | P02 (old), P01 (active), P03 (draft) | **P01** (only active) |
| Overheating charger bought 90 days ago | P01 (30-day window) vs P11 | **P11**: full refund at any time |
| Overheating device, customer asks for a replacement | P17 (replacement) vs P11 | **P11**: no replacement until investigation ends |
| Late parcel, agent wants to offer $15 credit | P07 ($5 / $10) vs P14 (agent limit $10) | **P07 amounts, P14 limits**: never above the tier, approval level applies |
| Customer demands $300 in cash | P14 vs P01 | **P14**: no cash, store credit only, escalate above $50 |
| Damage found 15 days after delivery | P04 (7-day report window) vs P01 (30-day defect return) | **P04 clause 2.2**: handled as a P01 defective return |
| Device fault 4 months after purchase | P01 (30 days) vs P12 (12-month warranty) | **P12**: repair or replace, no cash refund |
| Overheating plus "I'll go to the news" | P11 vs P15 | **Both apply**: P11 handles the refund and goodwill, P15 requires escalation |
