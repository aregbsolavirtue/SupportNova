# VoltCart Dataset Pack (SupportNova project)

Everything the team needs to build and test the system: a fictional company, **100 rules, 20 policy documents and 500 complaints**. All three datasets were generated from one source, so they agree with each other (checked by `scripts/validate.py`, 0 errors).

## Contents
| File / folder | What it is | Who uses it |
|---|---|---|
| `rule_matrix.csv` | 100 rules (the Rule Matrix) | Faith (validation), Isaac (SLA), Avis (prompt context) |
| `policies/` | 20 policy documents (12 DOCX, 8 PDF) | Ajoke (upload, chunking, retrieval) |
| `policy_registry.csv` | Status, version, precedence level of each policy | Ajoke |
| `complaints.csv` | 500 complaints with the expected correct answers | Everyone (testing), Isaac (duplicates), Nelius (demo data) |
| `POLICY_PRECEDENCE.md` | Which policy wins in a conflict, with test cases | Ajoke, Faith |
| `voltcart_profile.md` | Company profile and key business facts | Everyone |
| `scripts/` | Generators and `validate.py` | Virtue |

## Master lists (use these exact words everywhere)
- **Categories (6):** Damaged Product, Refund Request, Billing Error, Shipping Delay, Safety Issue, Technical Problem
- **Departments (5):** Returns, Billing, Shipping, Technical Support, Safety
- **Category to department:** Damaged Product > Returns | Refund Request > Billing | Billing Error > Billing | Shipping Delay > Shipping | Safety Issue > Safety | Technical Problem > Technical Support
- **Urgency:** Low, Medium, High
- **Escalation:** Yes, No
- **Approval levels:** Agent (up to $10), Manager (up to $50), Admin (above $50)

Note: "Damaged Product" also covers wrong, missing and used-as-new items (all handled by Returns).

## Rule Matrix columns (`rule_matrix.csv`)
`rule_id, category, subcategory, condition, department, urgency, escalate, refund_allowed (Yes/No/Conditional/N/A), refund_window_days (number, "Any" or blank), replacement_allowed, max_compensation_usd, compensation_type, approval_level, proof_required, sla_first_response_hours, sla_resolution_hours, policy_id, related_policy_ids`

`max_compensation_usd` is the most the AI may *offer*; it is store credit only and needs the listed approval level.

## Complaints columns (`complaints.csv`)
Input fields: `complaint_id, submitted_at, customer_id, order_id, product, order_value_usd, complaint_text`
Labels: `complaint_type, is_duplicate, duplicate_of, attack_type, notes`
**Expected answers:** `expected_rule_id, secondary_rule_id, expected_category, expected_subcategory, expected_department, expected_urgency, expected_escalation, expected_refund_allowed, expected_max_compensation_usd, expected_policy_id, expected_action`

Feed only the input fields to the system. Use the `expected_*` columns to score it.

| complaint_type | Count | What it tests |
|---|---|---|
| normal | 100 | Clear, polite complaints (1 per rule) |
| casual | 100 | Short, informal complaints (1 per rule) |
| angry | 100 | Capitals, exclamation marks, rude tone; same facts as normal |
| typos | 50 | Misspellings and lowercase text |
| duplicate_exact | 30 | Identical text resent (Isaac's duplicate detection) |
| duplicate_reworded | 20 | Same problem, different wording |
| repeat_followup | 10 | Third contact on the same issue, must escalate |
| multi_issue | 20 | Two problems in one message |
| vague | 20 | Too little information, system should ask a clarification question |
| non_english | 10 | Spanish and French |
| attack_embedded | 25 | Real complaint plus a hidden instruction (prompt injection) |
| attack_pure | 15 | Not a complaint: injection, SQL/XSS, spam, threats, gibberish |

`expected_action` values: `process_normally, flag_duplicate, flag_repeat_and_escalate, process_primary_note_secondary, ask_clarification, ignore_injection_and_process, reject_or_manual_review, escalate_and_manual_review`.

## Policy documents
| ID | Title | Version | Status | Format |
|---|---|---|---|---|
| P01 | Refund Policy | 2.0 | Active | DOCX |
| P02 | Refund Policy | 1.0 | **Old** (14-day refund) | PDF |
| P03 | Refund Policy | 3.0 | **Draft** (45-day refund) | PDF |
| P04 | Damaged Items Policy | 1.0 | Active | DOCX |
| P05 | Wrong or Missing Item Policy | 1.0 | Active | DOCX |
| P06 | Shipping and Delivery Policy | 1.0 | Active | PDF |
| P07 | Late Delivery Compensation Policy | 1.0 | Active | DOCX |
| P08 | Lost, Stolen or Undelivered Packages Policy | 1.0 | Active | PDF |
| P09 | Billing Errors and Payment Disputes Policy | 1.0 | Active | DOCX |
| P10 | Payment Failures and Pending Charges Policy | 1.0 | Active | DOCX |
| P11 | Safety Incident Policy | 1.2 | Active | DOCX |
| P12 | Warranty Policy | 1.0 | Active | PDF |
| P13 | Technical Support Policy | 1.0 | Active | DOCX |
| P14 | Compensation and Goodwill Policy | 1.1 | Active | DOCX |
| P15 | Escalation Policy | 1.0 | Active | DOCX |
| P16 | Urgency and SLA Policy | 1.0 | Active | PDF |
| P17 | Replacement Policy | 1.0 | Active | DOCX |
| P18 | Order Cancellation Policy | 1.0 | Active | DOCX |
| P19 | Customer Communication and Privacy Policy | 1.0 | Active | PDF |
| P20 | Promotions, Coupons and Price Adjustments Policy | 1.0 | Active | PDF |

Each document starts with a metadata table (ID, version, status, effective date, precedence level) so the parser can read the status from the file itself. File names do **not** contain the status, on purpose.

## Known design choices
- All 100 rules point only to **Active** policies. Old and Draft policies exist to test version handling.
- Only VoltPhone Ultra and VoltBook Pro 15 exceed $1,000, so only those trigger the high-value escalation.
- The 500 complaints are template-based (2 hand-written versions per rule, plus generated variations). They are realistic but not real customer data. Say so in the project report.
- CSV files are UTF-8. Open in Excel via Data > From Text/CSV to show the Spanish and French accents correctly.

## Regenerate / check
```
cd scripts
python build_tables.py && python build_complaints.py && node build_docx.js && python build_pdf.py && python validate.py
```
(Create `out/policies/` first. Generators write to `out/`.)
